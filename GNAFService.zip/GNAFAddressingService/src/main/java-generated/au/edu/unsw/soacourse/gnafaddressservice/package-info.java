@javax.xml.bind.annotation.XmlSchema(namespace = "http://gnafaddressservice.soacourse.unsw.edu.au")
package au.edu.unsw.soacourse.gnafaddressservice;
