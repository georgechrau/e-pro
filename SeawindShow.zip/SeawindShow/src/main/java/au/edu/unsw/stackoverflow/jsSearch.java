package au.edu.unsw.stackoverflow;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;


public class jsSearch {

	public static String getID(String path, String searchKey) {

//		String cmd = "echo "+ searchKey + "|" + path + "\\findkey.py";;
		String cmd = "cmd.exe /c echo "+ searchKey + "|" + path + "\\findkey.py";
		Runtime run = Runtime.getRuntime();
		String result = "";
		try {
			Process p = run.exec(cmd);
			BufferedInputStream in = new BufferedInputStream(p.getInputStream());
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String lineStr;
			while ((lineStr = br.readLine()) != null) {
				result += lineStr;
			}
			br.close();
			in.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
}
